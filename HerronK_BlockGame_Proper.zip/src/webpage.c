const char * main_page_html="<!DOCTYPE html> \
<html><style>a {text-decoration: none;color:#000000;}  \
div {padding:15px;} \
</style> \
<body style=\"font-family:Verdana;\"> \
<a href=/red> \
<div style=\"background-color:#f10101;\"> \
  <h1>Red</h1> \
</div></a> \
<a href=/green> \
<div style=\"background-color:#01f101;\"> \
  <h1>Green</h1> \
</div></a> \
<a style=\"color:#ffffff;\" href=/blue> \
<div style=\"background-color:#0101f1;\"> \
  <h1>Blue</h1> \
</div></a> \
</body> \
</html> \
";
